#!/bin/sh

echo "bash script is running \n\n"
echo "The largest process "
ps axu --sort -rss | head -n 4
echo "\n\n"

echo "The smallest process"
ps axu --sort -rss | tail -n 3
echo "\n\n"

echo "The youngest process"
ps axu --sort=start_time | tail -n 3
echo "\n\n"

echo "The oldest process"
ps axu --sort=start_time | head -n 4
