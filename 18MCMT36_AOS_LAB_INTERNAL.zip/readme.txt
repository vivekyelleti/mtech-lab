I used Command Line Arguments

first.c

To Compile and Run :

cc <c file with extension>
./a.out <input file with extension> <output file with extension>

To view the output :

cat <output file with extension>

sec.sh

To compile and Run:

chmod +x sec.sh
./sec.sh
