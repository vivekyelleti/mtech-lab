#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(int argc,char *argv[])
{
	FILE *fp=NULL;
	long lim;
        fp=fopen(argv[1],"r");
	fscanf(fp,"%ld\n",&lim);
	int *roll=(int*)malloc(lim*sizeof(int));
	float *marks=(float*)malloc(lim*sizeof(float));
	float sum=0;
	for(int i=0;i<lim;i++){
		fscanf(fp,"%d,",&roll[i]);
		fscanf(fp,"%f\n",&marks[i]);
		sum+=marks[i];
	}
	float avg=(sum/lim);
	int fd[4];
	pipe(fd);
	if(fork()!=0)
	{
		close(fd[0]);
		write(fd[1],roll,10);
		write(fd[2],marks,10);
		write(fd[3],&avg,10);
		close(fd[1]);
		close(fd[2]);
		close(fd[3]);
	}
	else
	{
		close(fd[1]);
		read(fd[0],roll,10);
		read(fd[0],marks,10);
		read(fd[0],&avg,10);
		FILE *dp=fopen(argv[2],"w+");
		fprintf(dp,"Average Marks: %f\n",avg);
                //FILE *dp=fopen(argv[2],"w+");
                fprintf(dp,"%s\t%s\t%s\n","roll","marks","satus");
		for(int i=0;i<lim;i++)
		{
			if(marks[i]==avg)
				fprintf(dp,"%d\t%f\tAverage\n",roll[i],marks[i]);
			else if(marks[i]>avg)
				fprintf(dp,"%d\t%f\tAboveAverage\n",roll[i],marks[i]);
			else
				fprintf(dp,"%d\t%f\tLessAverage\n",roll[i],marks[i]);	
		}
       printf("\nCheck %s for the output\n\nTo view Output \n\nCat <output with extension>\n",argv[2]);
       }
	return 0;
}
