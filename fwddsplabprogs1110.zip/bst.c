#include<stdio.h>
#include<stdlib.h>

struct bst
{
double *data;
struct bst *l;
struct bst *r;
};

typedef struct bst bst;

bst *h;
int lim;
//FILE *fp;

bst *mknode(int d)
{
bst *k=(bst*)malloc(sizeof(bst));
k->data=d;
k->l=NULL;
k->r=NULL;
return k;
}

void placeval(double d,bst *t)
{
//printf("p\n");
if(d <= t->data)
{
if(t->l==NULL)
{
bst *k=mknode(d);
t->l=k;
//printf("dp\n");
}
else
placeval(d,t->l);
}

if(d>t->data)
{
if(t->r==NULL)
{
bst *k=mknode(d);
t->r=k;
}
else
placeval(d,t->r);
}
}

int construct(char *c)
{
int k=0;
double d;
printf("%s",c);
FILE *fp=fopen(c,"r+");
fscanf(fp,"%d",&k);
fscanf(fp,"%lf",&d);
k=1;
while(k<lim)
{
//printf("it\n");
fscanf(fp,"%lf",&d);
printf("value of :: %lf\n",d);
placeval(d,h);
k=k+1;
}
fclose(fp);
}


int inorder(bst *g)
{
if(g!=NULL)
{
inorder(g->l);
printf("%lf ,\t",g->data);
inorder(g->r);
}
}


int postorder(bst *g)
{
if(g!=NULL)
{
postorder(g->l);
postorder(g->r);
printf("%lf ,\t",g->data);
}
}

int preorder(bst *g)
{
if(g!=NULL)
{
printf("%lf ,\t",g->data);
preorder(g->l);
preorder(g->r);
}
}



int main(int argc,char *argv[])
{
FILE *fp=fopen(argv[1],"r+");

fscanf(fp,"%d",&lim);
lim=abs(lim);
h=(bst*)malloc(sizeof(bst));
double d;
fscanf(fp,"%lf",&d);
printf("main %lf::\n",d);
h=mknode(d);
fclose(fp);
construct(argv[1]);
printf("Inorder ::\n");
inorder(h);
printf("\nPreorder ::\n");
preorder(h);
printf("\nPosrorder ::\n");
postorder(h);
}
