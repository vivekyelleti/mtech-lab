#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 100
struct bst
{
char data[MAX];
struct bst *l;
struct bst *r;
};

typedef struct bst bst;

bst *h;
int lim;
//FILE *fp;

bst *mknode(char d[MAX])
{
bst *k=(bst*)malloc(sizeof(bst));
strcpy(k->data,d);
k->l=NULL;
k->r=NULL;
return k;
}

int comp(char *a,char *b)
{
printf("Stringcmp %d",strcmp(a,b));
if(strcmp(a,b)>0)
return 0;
else
return 1;
}

void placeval(char d[MAX],bst *t)
{
//printf("p\n");
if(comp(d, t->data))
{
if(t->l==NULL)
{
bst *k=mknode(d);
t->l=k;
//printf("dp\n");
}
else
placeval(d,t->l);
}
else
{
if(t->r==NULL)
{
bst *k=mknode(d);
t->r=k;
}
else
placeval(d,t->r);
}
}

int construct(char *c)
{
int k=0;
char d[MAX];
printf("%s",c);
FILE *fp=fopen(c,"r+");
fscanf(fp,"%d",&k);
fscanf(fp,"%s",d);
k=1;
while(k<lim)
{
//printf("it\n");
fscanf(fp,"%s",d);
printf("value of :: %s\n",d);
placeval(d,h);
k=k+1;
}
fclose(fp);
}


int inorder(bst *g)
{
if(g!=NULL)
{
inorder(g->l);
printf("%s ,\t",g->data);
inorder(g->r);
}
}


int postorder(bst *g)
{
if(g!=NULL)
{
postorder(g->l);
postorder(g->r);
printf("%s ,\t",g->data);
}
}

int preorder(bst *g)
{
if(g!=NULL)
{
printf("%s ,\t",g->data);
preorder(g->l);
preorder(g->r);
}
}



int main(int argc,char *argv[])
{
FILE *fp=fopen(argv[1],"r+");

fscanf(fp,"%d",&lim);
lim=abs(lim);
h=(bst*)malloc(sizeof(bst));
char d[MAX];
fscanf(fp,"%s",d);
printf("main %s::\n",d);
h=mknode(d);
fclose(fp);
construct(argv[1]);
printf("\n\nInorder ::\n");
inorder(h);
printf("\nPreorder ::\n");
preorder(h);
printf("\nPosrorder ::\n");
postorder(h);
}
