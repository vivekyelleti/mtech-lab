#include<stdio.h>
#include<time.h>
#include<math.h>

int main(int argc,char *argv[])
{
	long int i=atoi(argv[1]);
	char *c;
	int n=0;
	time_t t;
	c=argv[2];
// Random I/p File generation
	FILE *fp;
	long int vall=0;
	fp=fopen(argv[2],"w+");
	fprintf(fp,"%ld\n",i);
	srand(time(&t));
	while(n<=i)
	{
		vall=rand()%(2*i+1);
		vall=vall-i;
		fprintf(fp,"%ld\n",vall);
		n++;
	}
	fclose(fp);
	printf("Radnom file generated\n");
	FILE *fp1;
// Ascending Order I/p file generation
	fp1=fopen(argv[3],"w+");
	fprintf(fp1,"%ld\n",i);
	srand(time(&t));
	long int in=rand()%i;
	in-=i;
	long int j=in;
	for(;j<(i+in);j++)
	{
		fprintf(fp1,"%ld\n",j);
	}
	fclose(fp1);
	printf("Ascending order file prepared\n");
// Descending order I/p file generation
	FILE *fp2;
	fp2=fopen(argv[4],"w+");
	fprintf(fp2,"%ld",i);
	srand(time(&t));
	in=rand()%i;
	j=in;
	for(;j>(-i+in);j--)
	{
		fprintf(fp2,"%ld\n",j);
	}
	fclose(fp2);
	printf("Descending order prepared\n");
	return 0;
}

