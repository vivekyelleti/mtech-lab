#include<stdio.h>
#include<stdlib.h>
struct op
{
long int swaps;
long int comparisons;
}dt;

int swap(long int *ip,int l,int h)
{
	long int t=ip[l];
	ip[l]=ip[h];
	ip[h]=t;
	return 0;
}

long int partition(long int *ip,int l, int h)
{
	long int i=l,j=h;
        long int pivot=ip[l];
	while(i<=j)
	{
		dt.comparisons=dt.comparisons+1;
		while((ip[i]<=pivot)&&(i<=h))
			{i++;}
                while((ip[j]>pivot)&&(j>=l))
                        {j--;}
		if(i<=j)
                {
		dt.swaps=dt.swaps+1;
		swap(ip,i,j);
		}
	}
        if(j!=l)
	dt.swaps=dt.swaps+1;
	swap(ip,j,l);
	return j;
}


int quick(long int *ip,int l,int h,int lim)
{
	int sortedel=0;
	if(l<h)
	{
		sortedel=partition(ip,l,h);
//		printf("Sorted %d\n",sortedel);
//                print(ip,h,lim);
//                printf("\n");
		quick(ip,l,sortedel-1,lim);
		quick(ip,sortedel+1,h,lim);
	}
	return 0;
}

int main(int argc,char *argv[])
{
	int lim=0;
	FILE *fp;
	fp=fopen(argv[1],"r");
//	printf("file\n");
	fscanf(fp,"%d",&lim);
//	printf("lim\n");
	long int *ip;
	ip=(long int*)malloc(sizeof(long int)*(lim));
//	printf("ip ary\n");
	int i=0;
	int val;
	while(fscanf(fp,"%d",&val)!=EOF)
	{
		ip[i]=val;
		i++;
	}
	quick(ip,0,lim-1,lim-1);
        fclose(fp);
        FILE *dp=fopen(argv[2],"w+");
	fprintf(dp,"%ld\n",dt.comparisons);
	fprintf(dp,"%ld\n",dt.swaps);
	for(i=0;i<lim;i++)
	fprintf(dp,"%ld\n",ip[i]);	
        fclose(dp);
	printf("Check %s for output\n",argv[2]);
	return 0;
}
