#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main(int argc,char *argv[])
{
  int lim,max=0;
  int *ip,*count,*op;
  int i;
  FILE *fp;
  fp=fopen(argv[1],"r");
  int parse=-1;
  int size;
  char c;
  fscanf(fp,"%d",&size);
  ip=(int*)malloc(sizeof(int)*size);
  op=(int*)malloc(sizeof(int)*size);
  int val=0;
  int k=0;
  int ten=10,chng=0;
  val=1;
  int t;
  printf("File Was reading\n");
  char ch;
// This is done By reading char by char 
  while((ch=fgetc(fp))!=EOF)
    {
      if(ch=='\n')
	{
	  parse=-1;
	  ip[k]=val;
	  k++;
	  if(max < val)
	    max =val;
	  val=1;

	}
      else
	{
	  t=ch-48; 
// To get ascii value assigned ch to a integer which gives the respective Ascii value of the character . For suppose ch is 1 gives 49 so subtracting with 48 gives the value ...
	  if(parse==-1)
	    {
	      val=t;
	    }
	  else
	    chng=1;
	  parse=parse+1;
	  chng=parse;
	  int dd=1; // to compute 10 value
	  while(chng!=0)
	   {
	    dd=ten;
	    chng=chng-1;
	   }
	  val=val*dd;
	   if(parse!=0)
	     val=val+t;
	}
    }
  fclose(fp);
  printf("intialise the count\n");
  count=(int*)malloc(sizeof(int)*max);
  // Initialise the count array
  for(i=0;i<=max;i++)
    *(count+i)=0;
  // genrate the values 
  for(i=0;i<size;i++)
    *(count+ip[i])=*(count+ip[i])+1;
  // genrating the couting array modified
  printf("generate the values\n");
  for(i=1;i<=max;i++)
    *(count+i)=*(count+(i-1))+*(count+i);
  printf("calulcuating o/p\n");
  printf("created\n");
  for(i=0;i<size;i++)
    {
      *(count+ip[i])=*(count+ip[i])-1;
      *(op+*(count+ip[i]))=ip[i];
    }
  //print o/p
  FILE *dp;
  dp=fopen(argv[2],"w+");
  printf("\noutput values are\n");
  for(i=1;i<size;i++)
    {
      fprintf(dp,"%d\n",op[i]);
    }  
  fclose(dp);
  printf("Output file by name %s Created\n",argv[2]);
  return 0;
}
