#include<stdio.h>
#include<time.h>

int main(int argc,char *argv[])
{
	int i=atoi(argv[1]);
	char *c;
	int n=0;
	time_t t;
	c=argv[2];
	FILE *fp;
	fp=fopen(argv[2],"w+");
	fprintf(fp,"%d\n",i);
	srand(time(&t));
	int k=i/5;
	while(n<=i)
	{
		fprintf(fp,"%d\n",rand()%(k+1));
		n++;
	}
	printf("File under name %s Created\n",argv[2]);
	fclose(fp);
	return 0;
}

