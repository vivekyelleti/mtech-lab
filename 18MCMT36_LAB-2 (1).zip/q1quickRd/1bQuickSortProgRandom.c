#include<stdio.h>
#include<stdlib.h>

struct op
{
long int comparisons;
long int swaps;
}dt;


int swap(long int *ip,int l,int h)
{
	long int t=ip[l];
	ip[l]=ip[h];
	ip[h]=t;
}




long int partition(long int *ip,int l, int h,int lim)
{
	long int i=l,j=h;
//	printf("L%d\tH%d\n",l,h);
        long int pivot=ip[l];
	while(i<=j)
	{
		dt.comparisons=dt.comparisons+1;
		while((ip[i]<=pivot))
			{i++;}
                while((ip[j]>pivot))
                        {j--;}
		if(i<=j)
                {
		printf("... I %ld\t J %ld\n",i,j);
		dt.swaps=dt.swaps+1;
		swap(ip,i,j);
		}
	}
	swap(ip,j,l);
//        printf("I%ld\tJ%ld\n",i,j);
	return j;
}

/*long int partition(long int *ip,int l, int h,int lim)
{
	long int i=l,j=h;
//	time_t t;
	printf("L%d\tH%d\n",l,h);
	srand(time(&t));
        long int r=rand()%(h-l+1);
	r=r+l;
	int d=0;
        printf("rand %ld\n",r);
        long int pivot=ip[l];
//	long int ind=0;
	printf("Pivot %ld\n",pivot);
	while(i<j)
	{
		/*if((ip[j]==pivot)&&(j==r))
		{j--;d=0;printf("SJ---\n");}
		if((ip[i]==pivot)&&(i==r))
		{i++;d=1;printf("SI---\n");}
		while((ip[i]<pivot)&&(i<h))
			{printf("%ld\t%ld\n",ip[i],pivot);i++;printf("I ---\n");}
                while((ip[j]>pivot)&&(j>l))
                        {j--;printf("J----\n");}
		/* if((ip[j]==pivot)&&(j==r))
                {j--;d=0;printf("SJ---\n");}
                if((ip[i]==pivot)&&(i==r))
                {i++;d=1;printf("SI---\n");}
//		if((ip[j]==pivot)&&(j==r))j--;
		if(i<j)
		swap(ip,i,j);	
	}
	//if(ind=0)ind=i;
	//else ind=j;
/*	long int index=0;
	if(d==1)
	index=j;
	else
	index=i;
	swap(ip,j,l);
        printf("I%ld\tJ%ld\n",i,j);
	return j;
}*/

long int chpartition(long int *ip,int l,int h,int lim)
{
        time_t t;
        srand(time(&t));
        int r=l+rand()%(h-l+1);
        swap(ip,r,l);
//	printf("Randomly chose %ld\n",ip[r]);
        partition(ip,l,h,lim);
}
int quick(long int *ip,int l,int h,int lim)
{
	int sortedel=0;
	if(l<h)
	{
		sortedel=chpartition(ip,l,h,lim);
	//	printf("Sorted %d\n",sortedel);
            //    print(ip,h,lim);
		quick(ip,l,sortedel-1,lim);
		quick(ip,sortedel+1,h,lim);
	}
	return 0;
}

int main(int argc,char *argv[])
{
	int lim=0;
	FILE *fp;
	fp=fopen(argv[1],"r");
//	printf("file\n");
	fscanf(fp,"%d",&lim);
//	printf("lim\n");
	long int *ip;
	ip=(long int*)malloc(sizeof(long int)*(lim));
//	printf("ip ary\n");
	int i=0;
	int val;
	while(fscanf(fp,"%d",&val)!=EOF)
	{
		ip[i]=val;
		i++;
	}
	quick(ip,0,lim-1,lim-1);
        fclose(fp);
        FILE *dp=fopen(argv[2],"w+");
	fprintf(dp,"%ld\n",dt.comparisons);
	fprintf(dp,"%ld\n",dt.swaps);
	for(i=0;i<lim;i++)
	fprintf(dp,"%ld\n",ip[i]);
	printf("Ouptut file created under name %s\n",argv[2]);	
        fclose(dp);
	return 0;
}
