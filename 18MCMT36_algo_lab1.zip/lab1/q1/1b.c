#include<stdio.h>
#include<stdlib.h>
// 1.b Retreiving the data from the file and storing them in a FILE 
int main(int argc, char *argv[])
  {
    
    FILE *fp,*dp,*c;
    char ch;
    int count=0;
    char *st;
    int i=0;
    fp=fopen(argv[1],"r");
    dp=fopen(argv[2],"w");
    fseek(fp,0,SEEK_END);
    count=ftell(fp);
    printf("%d",count);
    fseek(fp,0,SEEK_SET);
    st=(char*)malloc(sizeof(char)*count);
    printf("started reading ...\n");
    while((ch=fgetc(fp))!=EOF)
      
      {
	printf("%c",ch);
	*(st+i)=ch;
	i++;
	fprintf(dp,"%c",ch);
      }
    printf("closing\n");
    fclose(dp);
    fclose(fp);
    return 0;
  }
