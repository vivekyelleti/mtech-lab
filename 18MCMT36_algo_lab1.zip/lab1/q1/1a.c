#include<stdio.h>
#include<stdlib.h>
#include<time.h>
// AIM :: Writing in to the FILE
int main()
  {
     FILE *fp;
     int i=0;
     time_t t;
     fp=fopen("exer3.txt","w+");
     srand(time(&t));
     for(i=0;i<10;i++)
     	fprintf(fp,"%d\n",rand());
     return 0;
  }
