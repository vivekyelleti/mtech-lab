#include<stdio.h>
#include<stdlib.h>
#include<time.h>

// AIM :: To record the TIME COMPLEXITY of O(n)

int main(int argc,char*argv[]){
int i=0;
clock_t st,en;
st=clock();
for(i=0;i<atoi(argv[1]);i++);
en=clock();
printf(" Execution time for %d size :: %lf\n",atoi(argv[1]),((double)(en-st)/CLOCKS_PER_SEC));
return 0;
}
