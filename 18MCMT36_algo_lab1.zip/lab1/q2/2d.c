#include<stdio.h>
#include<stdlib.h>
#include<time.h>

// AIM :: To complete the TIME COMPLEXITY of O(n^3)

int main(int argc,char *argv[])
  {
    clock_t st,end;
    int i,j,k;
    st=clock();
    for(i=0;i<atoi(argv[1]);i++)
      {
	for(j=0;j<atoi(argv[1]);j++)
	  {
	    for(k=0;k<atoi(argv[1]);k++);
	  }
      }
    end=clock();
    printf("execution time of %d i/p is :: %lf\n",atoi(argv[1]),(double)(end-st)/CLOCKS_PER_SEC);
    return 0;
  }
