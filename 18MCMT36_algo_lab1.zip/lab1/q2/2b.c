#include<stdio.h>
#include<time.h>

//AIM :: To observe the TIME COMPLEXITY of O(logn)

int main()
{
	int n;
	int i=1;
	clock_t st,ed;
	st=clock();
	printf("Enter the I/p size\n");
	scanf("%d",&n);
	while(i<n)
	  {
		i=i*2;
	  }
	ed=clock();
	printf("EXecution time :: %lf\n",((double)(ed-st)/CLOCKS_PER_SEC));
	return 0;
}
