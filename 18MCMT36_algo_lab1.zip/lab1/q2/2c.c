#include<stdio.h>
#include<stdlib.h>
#include<time.h>

// AIM :: To calculate the Time complexity of O(n^2)

int main(int argc,char* argv[])
  
 {
   int i,j;
   clock_t st,end;
   st=clock();
   for(i=0;i<atoi(argv[1]);i++)
     {
       for(j=0;j<atoi(argv[1]);j++);
     }
   end=clock();
   printf("Execution time of %d Input size :: %lf\n",atoi(argv[1]),(double)(end-st)/CLOCKS_PER_SEC);
   return 0;
 }
