#include<stdio.h>
#include<time.h>

// AIM :: To record the TIME COMPLEXITY of O(2^n)

int fib(int n)
{
	if(n==1)
	return 1;
	else if (n<1)
	return 1;
	else fib(n-1)+fib(n-2);
	return 0;
}

int main()
{
	int n;
	clock_t st,ed;
	st=clock();
	printf("Enter the input size\n");
	scanf("%d",&n);
	fib(n);
	ed=clock();
	printf("Execution time :: %lf\n",((double)(ed-st)/CLOCKS_PER_SEC));
	return 0;
}
