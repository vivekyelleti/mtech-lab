import java.net.*;
import java.io.*;
import java.util.*;

class client
	{
		public static void main(String[] args)
		{
		try
		{
		Scanner sc=new Scanner(System.in);
		DatagramSocket dsoc=new DatagramSocket();
		InetAddress id=InetAddress.getLocalHost();
		int port=Integer.parseInt(args[0]);
		DatagramPacket dp;
		byte[] sb;
		while(true)
			{
			System.out.println("Enter the data");
			String send=sc.nextLine();
			sb=send.getBytes();
			dp=new DatagramPacket(sb,sb.length,id,port);
			dsoc.send(dp);
			}
		}

		catch(Exception e)
		{
		System.out.println("Exception occured");
		}

	}
}
