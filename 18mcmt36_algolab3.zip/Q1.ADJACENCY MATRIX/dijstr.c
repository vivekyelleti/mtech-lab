#include<stdio.h>
#include<stdlib.h>
#define MAX 1000

struct heap
{
int pos;
int dis;
int id;
}*dt;

int *from;
int r,c,source;
int ct=0;
// PRINT LIST

void printlist(int r)
{
	int i=0;
	for(i=0;i<r;i++)
	printf("%d\t%d\t%d\n",dt[i].id,dt[i].pos,dt[i].dis);
	printf("\n");
}

// EXTRACT MIN
int extractmin(int r)
{
	return dt[0].id;
}

//CHECK UPDATION
void checkupdation(int ind,int **mat,int r)
{
	int j,i;
//printf("che %d\n",dt[ind]);
//printf("val\n%d\t",mat[ind][0]);
	printf("updation\n");

	for(j=0;j<ct;j++)
	{
		printf("val ::%d  %d\t",dt[j].id,mat[ind][dt[j].id]);
		if(mat[ind][j]>0)
		{
		printf("%d\t",dt[j].dis);
		int val=dt[0].dis+mat[ind][dt[j].id];
		printf("%d\t%d\n",dt[0].dis,val);
		if(val< (dt[j].dis))
		{
		printf("updated %d\t%d\n",ind,j);
		dt[j].dis=val;
		from[dt[j].id]=dt[0].id;
		}
		}
	}
	printf("\n");
}


int heapify(int n,int i)
{
//printf("heapyf\n");
	int r=2*i+1;
	int l=2*i+2;

//printf("P %d\t l %d\t r %d\n",i,l,r);

	int max=i;
	if((l<n)&&( dt[i].dis > dt[l].dis))
	max=l;	
	if((r<n)&&( dt[r].dis < dt[max].dis))
	max=r;

	int t;
	if(max==i){printf("m\n");return 0;}
	else
	{
//printf("tracked b/w %d\t%d\n",i,max);
//Index tracing
	struct heap t;
	t=dt[i];
	dt[i]=dt[max];
	dt[max]=t;
//dt[max].pos=max;
//dt[i].pos=i;
	heapify(n,max);
	}
}



int build(int ct)
{
	int i=0;
	i=ct/2-1;

	for(;i>=0;i--)
	{
	heapify(ct,i);
	printlist(r);
	}
	return 0;
}

int adjust(int r)
{
	int i=0;
	for(;i<r;i++)
	dt[i].pos=i;
}
//DIJISTRA MAIN

int dijistra(int **mat,int r,int c,int source)
{
	int i,j;
	build(r);
//printf("a\n");
	int at;
//int ct=r;

// Returning extract min
	for(i=0;i<r;i++)
	{
//printlist(r);
	adjust(r);
	if(i!=0)
	at=extractmin(r);
	else
	at=source;
//printf("b %d\n",at);
//printf("%d\n",dt[at].dis);
//printlist(r);
	checkupdation(at,mat,r);
	printf("First min iss ... %d....\n",at);
//printlist(r);
//ADJUST(R)
	struct heap t;
	t=dt[0];
	dt[0]=dt[ct-1];
	dt[ct-1]=t;
//dt[0].pos=0;
//dt[ct-1].pos=ct-1;
	ct=ct-1;
//printlist(r);

//r=r-1;
	build(ct);
//printlist(r);
	}

	return 0;
}




int main(int argc,char *argv[])
{
	FILE *fp=fopen(argv[1],"r+");
	FILE *dp=fopen(argv[2],"w+");
//int r,c;
	fscanf(fp,"%d",&r);
	fscanf(fp,"%d",&c);
	fscanf(fp,"%d",&source);
	int **mat;
	int i=0;
	mat=(int**)malloc(r*sizeof(long int));
	printf("b\n");
	for(;i<r;i++)
	mat[i]=(int*)malloc(sizeof(long int)*c);

	int lim=r*c;
	int pl=0,pc=0;
//char ch=' ';
	int val=0;
	int d=c+1;
	ct=r;
//dt=(int*)malloc(sizeof(int)*r);
	from=(int*)malloc(sizeof(int)*r);

	printf("reaading\n");
	int j=0;
	for(i=0;i<r;i++)
	{
	for(j=0;j<c;j++)
	{
	fscanf(fp,"%d",&val);
	printf("read val %d %d %d %d\n",i,j,val,lim);
	if(val==0)val=MAX;
	mat[i][j]=val;
	}
}

	printf("calling\n");

	dt=(struct heap*)malloc(sizeof(struct heap)*r);
	for(i=0;i<r;i++)
	{
	dt[i].pos=i;
	dt[i].dis=MAX;
	dt[i].id=i;
	from[i]=-1;
	}
//printlist(dt,r);

	dt[source].dis=0;
	from[source]=source;
//printlist(dt,r);
	dijistra(mat,r,c,source);
//printop(mat,r,c);

	printf("FROM ARRAY\n");
	fputs("FROM ARRAY\n",dp);
	fputs("VERTEX\t\tFROM VERTEX\n",dp);
	for(i=0;i<r;i++)
	{
	fprintf(dp,"%d",i);
	fputs("\t----\t",dp);
	fprintf(dp,"%d\n",from[i]);
	printf("%d----%d\n",i,from[i]);
	}

	printf("INDEX AND MINIMUM DISTANCE FROM THE SOURCE\n");
	fputs("INDEX AND MINIMUM DISTANCE FROM THE SOURCE\n",dp);
	for(i=0;i<r;i++)
	{
	printf("%d----%d\n",dt[i].id,dt[i].dis);
	fprintf(dp,"%d",dt[i].id);
	fputs("\t----\t",dp);
	fprintf(dp,"%d\n",dt[i].dis);
	}
	printf("\n");
	printf("Check op file %s\n\n\n",argv[2]);
return 0;
}
