#include <stdio.h>
#include <stdlib.h>
#define max 1000

struct list
{
struct node
{

    int dest;
    int weight;
    struct node* next;
}*head;
};

struct adj
{
    int id;
    struct list* arr;
};

struct node* form(int dest, int weight)
{
    struct node* ne =
            (struct node*) malloc(sizeof(struct node));
    ne->dest = dest;
    ne->weight = weight;
    ne->next = NULL;
    return ne;
}

struct adj* createadj(int id)
{
    struct adj* adj = (struct adj*) malloc(sizeof(struct adj));
    adj->id = id;
    int i=0;
    adj->arr = (struct list*) malloc(id * sizeof(struct list));

    for ( i = 0; i < id; ++i)
        adj->arr[i].head = NULL;
 
    return adj;
}

void add(struct adj* adj, int src, int dest, int weight)
{
    struct node* ne = form(dest, weight);
    ne->next = adj->arr[src].head;
    adj->arr[src].head = ne;

    ne = form(src, weight);
    ne->next = adj->arr[dest].head;
    adj->arr[dest].head = ne;
}

struct hnode
{
    int  v;
    int dist;
};

struct heap
{
    int size;
    int capacity;
    int *pos;
    struct hnode **arr;
};

struct hnode* create(int v, int dist)
{
    struct hnode* hnode =
           (struct hnode*) malloc(sizeof(struct hnode));
    hnode->v = v;
    hnode->dist = dist;
    return hnode;
}

struct heap* createheap(int capacity)
{
    struct heap* heap =
         (struct heap*) malloc(sizeof(struct heap));
    heap->pos = (int *)malloc(capacity * sizeof(int));
    heap->size = 0;
    heap->capacity = capacity;
    heap->arr =
         (struct hnode**) malloc(capacity * sizeof(struct hnode*));
    return heap;
}

void swap(struct hnode** a, struct hnode** b)
{
    struct hnode* t = *a;
    *a = *b;
    *b = t;
}
void heapify(struct heap* heap, int idx)
{
    int smallest, l, r;
    smallest = idx;
    l = 2 * idx + 1;
    r = 2 * idx + 2;
 
    if (l < heap->size &&
        heap->arr[l]->dist < heap->arr[smallest]->dist )
      smallest = l;
    if (r < heap->size &&
        heap->arr[r]->dist < heap->arr[smallest]->dist )
      smallest = r;
     if (smallest != idx)
    {

        struct hnode *smallestNode = heap->arr[smallest];
        struct hnode *idxNode = heap->arr[idx];
        heap->pos[smallestNode->v] = idx;
        heap->pos[idxNode->v] = smallest;
        swap(&heap->arr[smallest], &heap->arr[idx]);

        heapify(heap, smallest);
    }
}
int isEmpty(struct heap* heap)
{
    return heap->size == 0;
}
struct hnode* minn(struct heap* heap)
{
    if (isEmpty(heap))
        return NULL;
    struct hnode* root = heap->arr[0];
    struct hnode* lastNode = heap->arr[heap->size - 1];
    heap->arr[0] = lastNode;
    heap->pos[root->v] = heap->size-1;
    heap->pos[lastNode->v] = 0;
    --heap->size;
    heapify(heap, 0);

    return root;
}
void decreaseKey(struct heap* heap, int v, int dist)
{
    int i = heap->pos[v];

    heap->arr[i]->dist = dist;

    while (i && heap->arr[i]->dist < heap->arr[(i - 1) / 2]->dist)
    {
        heap->pos[heap->arr[i]->v] = (i-1)/2;
        heap->pos[heap->arr[(i-1)/2]->v] = i;
        swap(&heap->arr[i],  &heap->arr[(i - 1) / 2]);

        i = (i - 1) / 2;
    }
}

int isInheap(struct heap *heap, int v)
{
   if (heap->pos[v] < heap->size)
     return 1;
   return 0;
}

void dijkstra(struct adj* adj, int src, char *s)
{
    int id = adj->id;
    int dist[id];
    int v=0;
    struct heap* heap = createheap(id);
    for ( v = 0; v < id; ++v)
    {
        dist[v] = max;
        heap->arr[v] = create(v, dist[v]);
        heap->pos[v] = v;
    }

    heap->arr[src] = create(src, dist[src]);
    heap->pos[src]   = src;
    dist[src] = 0;
    decreaseKey(heap, src, dist[src]);

    heap->size = id;

    while (!isEmpty(heap))
    {
        struct hnode* hnode = minn(heap);
        int u = hnode->v;
        struct node* parse = adj->arr[u].head;
        while (parse != NULL)
        {
            int v = parse->dest;
            if (isInheap(heap, v) && dist[u] != max && 
                                          parse->weight + dist[u] < dist[v])
            {
                dist[v] = dist[u] + parse->weight;
                decreaseKey(heap, v, dist[v]);
            }
            parse = parse->next;
        }
    }
FILE *dp=fopen(s,"w+");
fputs("Vertex Distance from Source\n",dp);
printf("Vertex   Distance from Source\n");
int i=0;
    for (i = 0; i < id; ++i)
	{
        printf("%d \t\t %d\n", i, dist[i]);
        fprintf(dp,"%d",i);
	fputs("\t-----\t",dp);
	fprintf(dp,"%d\n",dist[i]);
	}
printf("Check the %s for output\n\n",s);
}
 
 
int main(int argc,char *argv[])
{
int source,rc,edge;
FILE *fp=fopen(argv[1],"r+");

fscanf(fp,"%d",&rc);
struct adj *adj=createadj(rc);
fscanf(fp,"%d",&source);
fscanf(fp,"%d",&edge);
int i=0;
int from;
int to;
int val;
for(i=0;i<edge;i++)
{
fscanf(fp,"%d",&from);
fscanf(fp,"%d",&to);
fscanf(fp,"%d",&val);
add(adj,from,to,val);
}
    dijkstra(adj, source,argv[2]);

    return 0;
}
