import java.net.*;
import java.io.*;
import java.util.*;

class client
	{
		public static String get(byte[] s)
		{
		String st=new String(s);
		System.out.println(st);
		return st;
		}
		public static void main(String[] args)
		{
		try
		{
		Scanner sc=new Scanner(System.in);
		DatagramSocket dsoc=new DatagramSocket();
		InetAddress id=InetAddress.getLocalHost();
		int port=Integer.parseInt(args[0]);
		DatagramPacket dp,drr;
		byte[] rb=new byte[555];
		drr=new DatagramPacket(rb,555);
		byte[] sb=new byte[555];
		while(true)
			{
			System.out.println("Enter the data");
			String send=sc.nextLine();
			sb=send.getBytes();
			dp=new DatagramPacket(sb,sb.length,id,port);
			dsoc.send(dp);
			drr=new DatagramPacket(rb,rb.length,id,port);
			dsoc.receive(drr);
			System.out.println("Received Res"+get(rb));

			}
		}

		catch(Exception e)
		{
		System.out.println("Exception occured");
		}

	}
}
