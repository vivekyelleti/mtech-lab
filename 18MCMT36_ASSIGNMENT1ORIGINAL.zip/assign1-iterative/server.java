import java.net.*;
import java.io.*;
import java.util.*;

public class server
{
	public static String get(byte[] s)
	{
	String st=new String(s);
	System.out.println(st);
	return st;
	}

	public static void main(String[] args)
	{
//Scaanner sc=new Scanner(System.in);
//InetAddress ip=new InetAddress.getLocalHost();
		try
		{
		int port=Integer.parseInt(args[0]);
//		int rport=Integer.parseInt(8984);
		DatagramSocket dsoc=new DatagramSocket(port);
		System.out.println("Client is bounded to "+port);
		DatagramPacket dpac=null;
		InetAddress id=InetAddress.getLocalHost();
		byte[] r=new byte[555];
		byte[] ans=new byte[555];
		String an=new String();
		int count=1;
		int a=0,b=0;
		int res=0;

		while(true)
		{
		System.out.println("Waiting for client repsonse");
		dpac=new DatagramPacket(r,555);
		dsoc.receive(dpac);
//System.out.println("Waiting for client response");
		StringTokenizer s=new StringTokenizer(get(r),",");
		count=0;
			while(s.hasMoreTokens())
			{
			switch(count)
			{
			case 1:a=Integer.parseInt(s.nextToken());
			System.out.println("A:"+a);
			break;
			case 2:b=Integer.parseInt(s.nextToken());
			System.out.println("B:"+b);
//if(s.nextToken().equals("+"))
//System.out.println(a+b);
			break;
			case 3:
//System.out.print(s.nextToken());
				switch(s.nextToken())
				{
				case "+":
				res=a+b;
				break;
				case "-": res=a-b;
				break;
				case "*": res=a*b;
				break;
				case "/": res=(int)a/b;
				break;
				case ">>":res=a>>b;
				break;
				case "<<": res=a<<b;
				break;
				}
			System.out.println("the res of "+"b/w the "+a+"and"+b+"is"+res);
			int rport = dpac.getPort();
			System.out.println("Received at "+rport);
			an=Integer.toString(res);
			ans=an.getBytes();
			DatagramPacket dr=new DatagramPacket(ans,ans.length,id,rport);
			System.out.println("sn");
			dsoc.send(dr);
			break;
		}
		count=count+1;
		if(count==4)
		break;
		}
		r=new byte[555];
		System.out.println("done");
//s=new String();
//st=new StringTokenizer();
		}
		}
		catch(Exception e)
		{
		System.out.println(e);
		}
	}
}
