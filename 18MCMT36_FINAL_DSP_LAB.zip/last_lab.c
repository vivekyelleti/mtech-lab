#include<stdio.h> 
#include<stdlib.h>

int **mat;
int *visit;


int *st,top=-1;
int track=0;
int flag=0;

void printpaths(int,int,int);

int push(int node)
{
top++;
st[top]=node;
}

int pop()
{
printf("popped element is %d\n",st[top]);
int node=st[top];
top--;
return node;
}

int dfs(int source, int lim ,int dest)
{
int i;
visit=(int*)malloc(sizeof(int)*lim);
for(i=0;i<lim;i++)
visit[i]=0;

visit[source]=1;

st=(int*)malloc(sizeof(int)*lim);
for(i=0;i<lim;i++)
st[i]=-1;


printpaths(source,lim,dest);
}

void printpaths(int source,int lim,int dest)
{
//front=0;
push(source);
int i=0;
int val=0;
visit[source]=1;
//push(source);

//int current=pop();
if(source==dest)
{
flag=1;
printf("\nPath is :: \n");
for(i=0;i<=top;i++)
printf("%d->",st[i]);
printf("\n\n");
}

else
{
for(i=0;i<lim;i++)
{
if(mat[source][i] > 0)
{
if(visit[i]==0)
{
//visit[i]=1;
printf("pushed  %d into stack\n",i);
printpaths(i,lim,dest);
}
}
}
}
//printf("top %d\n",top);

//if((top!=-1)&&(st[top]!=-1))
//continue;

//break;
//}
val=pop();

visit[source]=0;
}


int main(int argc,char *argv[])
{
FILE *fp=fopen(argv[1],"r+");

if(fp==NULL)               // FILE EXCEPTION
{
printf("file was not present\n");
return 0;
}

int lim;
fscanf(fp,"%d",&lim);
int i,j;
int source;
fscanf(fp,"%d",&source);
int destination;
fscanf(fp,"%d",&destination);

lim=abs(lim);                 // NEGATIVE VALUES EXCEPTION
source=abs(source);
destination=abs(destination);

mat=(int **)calloc(lim,sizeof(int*));
for(i=0;i<lim;i++)
mat[i]=(int*)malloc(sizeof(int)*lim);


if(source==destination)
{
printf("both the source and destination aree same\n");
return 0;
}


// input taken
int val=0;
for(i=0;i<lim;i++)
{
for(j=0;j<lim;j++)
{
fscanf(fp,"%d",&val);
mat[i][j]=val;
}
}

printf("DFS\n");
dfs(source,lim,destination);

if(flag==0)
printf("not a connected Graph\n");

return 0;
}
